# ThinkThread Agent POSIX SDK for TypeScript

`@thinkthread/agent-posix` is the typed Agent Control v2 client for Node.js components running
inside an authorized ThinkThread Agent execution. The npm package contains compiled ESM and type
declarations; it does not depend on ThinkThread's source checkout or binaries and runs no install-
time code generation.

```ts
import { AgentPosixClient } from "@thinkthread/agent-posix";

const client = AgentPosixClient.fromEnv();
const me = await client.selfView();
console.log(me.thinkthreadId);
```

Production transport supports Linux Node.js 20+. See `docs/getting-started.md`, `docs/contract.md`,
and `docs/errors.md`. Raw resource groups cover every Agent Control v2 method; `FsWorkflows`
provides bounded byte/file upload, stdin run-key/run, and ordered patch choreography.

The tarball produced by `npm pack` is self-contained compiled JavaScript and declarations. It uses
Ajv for runtime validation and has no native addon, install hook, ThinkThread binary, or embedded
repository path.
