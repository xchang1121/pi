import { AgentPosixClient, FsWorkflows } from "@thinkthread/agent-posix";

const client = AgentPosixClient.fromEnv();
const workflows = new FsWorkflows(client);
const payload = await workflows.uploadBytes(new TextEncoder().encode("hello from TypeScript\n"));
console.log(JSON.stringify(payload, null, 2));
