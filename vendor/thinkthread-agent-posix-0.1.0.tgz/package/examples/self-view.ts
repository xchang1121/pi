import { AgentPosixClient } from "@thinkthread/agent-posix";

const client = AgentPosixClient.fromEnv();
const view = await client.selfView();
console.log(JSON.stringify(view, null, 2));
