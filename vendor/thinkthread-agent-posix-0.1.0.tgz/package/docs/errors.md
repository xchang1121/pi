# Errors and delivery certainty

The SDK distinguishes configuration, validation, transport, protocol, and Runtime rejection
errors. `RejectedError.response` is the complete credential-free Control rejection.

Transport failures report `not_sent` only when connecting failed before request bytes could be
sent. Write, read, EOF, and malformed connection completion report `completion_unknown`. The SDK
never retries automatically; recover durable operations with their original request ID.
