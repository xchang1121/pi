# Getting started

Check out this repository's versioned Git tag, build the package tarball, and install it in an
Agent-side Node.js component:

```sh
git clone --branch v0.1.0 --depth 1 https://gitcode.com/aideveloper/capsule_public.git thinkthread-release
npm ci --prefix ./thinkthread-release/sdk/agent-posix/ts
npm pack ./thinkthread-release/sdk/agent-posix/ts
npm install ./thinkthread-agent-posix-0.1.0.tgz
```

```ts
import { AgentPosixClient } from "@thinkthread/agent-posix";

const client = AgentPosixClient.fromEnv();
const view = await client.selfView();
const children = await client.thinkthreads.list();
console.log(view.thinkthreadId, children.children.length);
```

`fromEnv()` reads the execution-local `THINKTHREAD_CONTROL_SOCKET` and
`THINKTHREAD_CONTROL_TOKEN`. Recreate the client after an execution restart. The SDK connects to
an existing Runtime; it does not install, start, or embed ThinkThread.

Raw group methods execute exactly one request and never retry or paginate. For ordinary bytes or
files, use the bounded workflow layer:

```ts
import { AgentPosixClient, FsWorkflows } from "@thinkthread/agent-posix";

const client = AgentPosixClient.fromEnv();
const workflows = new FsWorkflows(client);
const payload = await workflows.uploadBytes(new TextEncoder().encode("hello\n"));
console.log(payload.payloadId);
```

See `examples/self-view.ts` and `examples/upload-bytes.ts` for complete top-level examples.
