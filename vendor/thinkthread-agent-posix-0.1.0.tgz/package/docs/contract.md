# Contract and API layers

Generated contract types cover all Agent Control v2 methods. Resource identities are branded
strings with runtime prefix validation, and every Agent-visible integer is checked against
JavaScript's safe integer range.

`invoke(method, params)` is the one-request typed raw API. It does not retry, paginate, or upload
payloads. `uploadBytes`, `uploadFile`, `runWithStdinBytes`, and `runKeyWithStdinBytes` provide the
same bounded payload choreography as the Rust SDK.

Dynamic results remain typed: `fs.snapshot.stat` is a snapshot-or-entry union, and
`fs.request.status` is discriminated first by durable method and then by lifecycle state.
